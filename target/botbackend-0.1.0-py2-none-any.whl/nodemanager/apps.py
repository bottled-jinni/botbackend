from django.apps import AppConfig


class NodemanagerConfig(AppConfig):
    name = 'nodemanager'
